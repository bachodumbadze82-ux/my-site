import { pgTable, serial, text, boolean, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const keysTable = pgTable("keys", {
  id: serial("id").primaryKey(),
  keyValue: text("key_value").notNull().unique(),
  productId: text("product_id").notNull(),
  isUsed: boolean("is_used").notNull().default(false),
  usedBy: integer("used_by").references(() => usersTable.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertKeySchema = createInsertSchema(keysTable).omit({ id: true, createdAt: true });
export type InsertKey = z.infer<typeof insertKeySchema>;
export type Key = typeof keysTable.$inferSelect;
