import { Request, Response, NextFunction } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

declare module "express-session" {
  interface SessionData {
    userId: number;
  }
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
}

export async function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  try {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.session.userId)).limit(1);
    if (!user) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }
    const adminUsername = process.env.ADMIN_USERNAME;
    const isAdminUser = user.isAdmin && (!adminUsername || user.username === adminUsername);
    if (!isAdminUser) {
      res.status(403).json({ error: "Forbidden: Admin access only" });
      return;
    }
    (req as any).adminUser = user;
    next();
  } catch (err) {
    res.status(500).json({ error: "Internal server error" });
  }
}
