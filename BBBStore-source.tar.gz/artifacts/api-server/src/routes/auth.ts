import { Router, type IRouter, type Request, type Response } from "express";
import bcrypt from "bcryptjs";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

function getClientIP(req: Request): string {
  const forwarded = req.headers["x-forwarded-for"];
  if (forwarded) return String(forwarded).split(",")[0].trim();
  return req.ip || req.socket?.remoteAddress || "unknown";
}

async function lookupCountry(ip: string): Promise<string | null> {
  const isPrivate = ip === "127.0.0.1" || ip === "::1" || ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172.") || ip.startsWith("::ffff:127.");
  if (isPrivate) return null;
  try {
    const res = await fetch(`http://ip-api.com/json/${ip}?fields=countryCode,country,status`, { signal: AbortSignal.timeout(3000) });
    const data: any = await res.json();
    if (data.status === "success") return data.country || data.countryCode;
    return null;
  } catch { return null; }
}

const router: IRouter = Router();

function isAdminUsername(username: string): boolean {
  const adminUsername = process.env.ADMIN_USERNAME;
  return !!adminUsername && username === adminUsername;
}

router.post("/register", async (req: Request, res: Response) => {
  const { username, password } = req.body;

  if (!username || !password) {
    res.status(400).json({ error: "Username and password are required" });
    return;
  }
  if (username.length < 3 || username.length > 32) {
    res.status(400).json({ error: "Username must be between 3 and 32 characters" });
    return;
  }
  if (password.length < 6) {
    res.status(400).json({ error: "Password must be at least 6 characters" });
    return;
  }

  try {
    const existing = await db.select().from(usersTable).where(eq(usersTable.username, username)).limit(1);
    if (existing.length > 0) {
      res.status(400).json({ error: "Username already taken" });
      return;
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const shouldBeAdmin = isAdminUsername(username);

    const [user] = await db.insert(usersTable).values({
      username,
      passwordHash,
      balance: 0,
      isAdmin: shouldBeAdmin,
    }).returning();

    req.session.userId = user.id;

    res.json({
      user: { id: user.id, username: user.username, balance: user.balance, isAdmin: user.isAdmin },
      message: "Registered successfully",
    });
  } catch (err) {
    req.log.error({ err }, "Register error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/login", async (req: Request, res: Response) => {
  const { username, password } = req.body;

  if (!username || !password) {
    res.status(400).json({ error: "Username and password are required" });
    return;
  }

  try {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.username, username)).limit(1);
    if (!user) {
      res.status(400).json({ error: "Invalid username or password" });
      return;
    }

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      res.status(400).json({ error: "Invalid username or password" });
      return;
    }

    if (isAdminUsername(username) && !user.isAdmin) {
      await db.update(usersTable).set({ isAdmin: true }).where(eq(usersTable.id, user.id));
      user.isAdmin = true;
    }

    req.session.userId = user.id;

    const ip = getClientIP(req);
    lookupCountry(ip).then(country => {
      db.update(usersTable).set({ lastIp: ip, lastCountry: country, lastSeenAt: new Date() }).where(eq(usersTable.id, user.id)).catch(() => {});
    });

    res.json({
      user: { id: user.id, username: user.username, balance: user.balance, isAdmin: user.isAdmin },
      message: "Logged in successfully",
    });
  } catch (err) {
    req.log.error({ err }, "Login error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/logout", (req: Request, res: Response) => {
  req.session.destroy((err) => {
    if (err) {
      req.log.error({ err }, "Logout error");
      res.status(500).json({ error: "Internal server error" });
      return;
    }
    res.json({ message: "Logged out successfully" });
  });
});

router.get("/me", async (req: Request, res: Response) => {
  if (!req.session.userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  try {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.session.userId)).limit(1);
    if (!user) {
      req.session.destroy(() => {});
      res.status(401).json({ error: "Unauthorized" });
      return;
    }

    res.json({ id: user.id, username: user.username, balance: user.balance, isAdmin: user.isAdmin });
  } catch (err) {
    req.log.error({ err }, "Get me error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
