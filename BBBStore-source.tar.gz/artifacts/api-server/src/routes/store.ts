import { Router, type IRouter, type Request, type Response } from "express";
import { db, usersTable, keysTable, purchasesTable, depositsTable, settingsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

const PRODUCTS = [
  { id: "1day",  name: "1 Day Access",  duration: "1 day",   price: 7,  description: "Full access for 1 day",   currency: "USD" },
  { id: "7day",  name: "7 Day Access",  duration: "7 days",  price: 20, description: "Full access for 7 days",  currency: "USD" },
  { id: "30day", name: "30 Day Access", duration: "30 days", price: 30, description: "Full access for 30 days", currency: "USD" },
];

const GEL_CATEGORIES: Record<string, { name: string; tier: "A" | "B" }> = {
  "king-ios":  { name: "KING IOS",  tier: "A" },
  "oasis":     { name: "Oasis",     tier: "A" },
  "dolphin":   { name: "Dolphin",   tier: "B" },
  "ios-star":  { name: "Ios Star",  tier: "B" },
  "ios-zoon":  { name: "Ios Zoon",  tier: "B" },
};

const GEL_DURATIONS = [
  { id: "1day",  label: "1 Day",   tierA: 15, tierB: 10 },
  { id: "7day",  label: "1 Week",  tierA: 40, tierB: 35 },
  { id: "30day", label: "1 Month", tierA: 80, tierB: 60 },
];

const GEL_PRODUCTS = Object.entries(GEL_CATEGORIES).flatMap(([catId, cat]) =>
  GEL_DURATIONS.map(dur => ({
    id: `${catId}-${dur.id}`,
    name: `${cat.name} — ${dur.label}`,
    duration: dur.label,
    price: cat.tier === "A" ? dur.tierA : dur.tierB,
    currency: "GEL",
    category: catId,
    categoryName: cat.name,
    durationId: dur.id,
  }))
);

function getClientIP(req: Request): string {
  const forwarded = req.headers["x-forwarded-for"];
  if (forwarded) return String(forwarded).split(",")[0].trim();
  return req.ip || req.socket.remoteAddress || "127.0.0.1";
}

function isPrivateIP(ip: string): boolean {
  return (
    ip === "127.0.0.1" || ip === "::1" ||
    ip.startsWith("192.168.") || ip.startsWith("10.") ||
    ip.startsWith("172.16.") || ip.startsWith("172.31.") ||
    ip.startsWith("::ffff:127.")
  );
}

async function lookupCountry(ip: string): Promise<string | null> {
  if (isPrivateIP(ip)) return null;
  try {
    const res = await fetch(`http://ip-api.com/json/${ip}?fields=countryCode,status`, { signal: AbortSignal.timeout(3000) });
    const data: any = await res.json();
    if (data.status === "success") return data.countryCode;
    return null;
  } catch {
    return null;
  }
}

router.get("/geo", async (req: Request, res: Response) => {
  const sess = req.session as any;
  if (sess.geoCountry !== undefined) {
    res.json({ country: sess.geoCountry, isGeorgian: sess.geoCountry === "GE" });
    return;
  }
  const ip = getClientIP(req);
  const country = await lookupCountry(ip);
  sess.geoCountry = country;
  res.json({ country, isGeorgian: country === "GE" });
});

router.get("/products", (_req: Request, res: Response) => {
  res.json(PRODUCTS);
});

router.get("/gel-products", async (req: Request, res: Response) => {
  const sess = req.session as any;
  const country = sess.geoCountry !== undefined ? sess.geoCountry : await lookupCountry(getClientIP(req));
  if (country !== "GE") {
    res.status(403).json({ error: "Georgian prices are only available for Georgian users." });
    return;
  }
  res.json(GEL_PRODUCTS);
});

router.post("/purchase", requireAuth, async (req: Request, res: Response) => {
  const { productId } = req.body;

  const usdProduct = PRODUCTS.find((p) => p.id === productId);
  const gelProduct = GEL_PRODUCTS.find((p) => p.id === productId);
  const product = usdProduct || gelProduct;

  if (!product) {
    res.status(400).json({ error: "Invalid product" });
    return;
  }

  if (gelProduct) {
    const sess = req.session as any;
    const country = sess.geoCountry !== undefined ? sess.geoCountry : await lookupCountry(getClientIP(req));
    if (country !== "GE") {
      res.status(403).json({ error: "Georgian prices are only available for Georgian users." });
      return;
    }
  }

  const userId = req.session.userId!;
  try {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
    if (!user) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }
    if (user.balance < product.price) {
      const sym = gelProduct ? "₾" : "$";
      res.status(400).json({ error: `Insufficient balance. You have ${sym}${user.balance.toFixed(2)}, need ${sym}${product.price}` });
      return;
    }
    const [availableKey] = await db
      .select()
      .from(keysTable)
      .where(and(eq(keysTable.productId, productId), eq(keysTable.isUsed, false)))
      .limit(1);
    if (!availableKey) {
      res.status(400).json({ error: "No keys available for this product right now. Contact admin." });
      return;
    }
    await db.update(usersTable).set({ balance: user.balance - product.price }).where(eq(usersTable.id, userId));
    await db.update(keysTable).set({ isUsed: true, usedBy: userId }).where(eq(keysTable.id, availableKey.id));
    await db.insert(purchasesTable).values({
      userId,
      productId,
      productName: product.name,
      keyValue: availableKey.keyValue,
      price: product.price,
    });
    res.json({ key: availableKey.keyValue, productName: product.name, message: `Successfully purchased ${product.name}` });
  } catch (err) {
    req.log.error({ err }, "Purchase error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/history", requireAuth, async (req: Request, res: Response) => {
  const userId = req.session.userId!;
  try {
    const purchases = await db.select().from(purchasesTable).where(eq(purchasesTable.userId, userId));
    res.json(purchases.map((p) => ({
      id: p.id,
      productId: p.productId,
      productName: p.productName,
      keyValue: p.keyValue,
      price: p.price,
      purchasedAt: p.purchasedAt.toISOString(),
    })).reverse());
  } catch (err) {
    req.log.error({ err }, "History error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/payment-info", async (_req: Request, res: Response) => {
  try {
    const SETTING_KEYS = ["btcAddress", "ethAddress", "usdtAddress", "bankName", "bankAccount", "bankHolder", "bankNote", "bogIban", "tbcIban", "binanceId", "giftCardInfo"];
    const rows = await db.select().from(settingsTable);
    const result: Record<string, string> = {};
    for (const key of SETTING_KEYS) result[key] = "";
    for (const row of rows) result[row.key] = row.value;
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/deposits", requireAuth, async (req: Request, res: Response) => {
  const userId = req.session.userId!;
  try {
    const deposits = await db.select().from(depositsTable).where(eq(depositsTable.userId, userId));
    res.json(deposits.map(d => ({
      id: d.id,
      amount: d.amount,
      method: d.method,
      proof: d.proof,
      status: d.status,
      adminNote: d.adminNote,
      createdAt: d.createdAt.toISOString(),
    })).reverse());
  } catch (err) {
    req.log.error({ err }, "Get deposits error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/deposits", requireAuth, async (req: Request, res: Response) => {
  const userId = req.session.userId!;
  const { amount, method, proof } = req.body;
  if (!amount || !method || !proof) {
    res.status(400).json({ error: "amount, method, and proof are required" });
    return;
  }
  const numAmount = Number(amount);
  if (isNaN(numAmount) || numAmount <= 0) {
    res.status(400).json({ error: "amount must be a positive number" });
    return;
  }
  const validMethods = ["btc", "eth", "usdt", "bank", "bog", "tbc", "binance", "giftcard"];
  if (!validMethods.includes(method)) {
    res.status(400).json({ error: "method must be: btc, eth, usdt, bank, bog, tbc, binance, or giftcard" });
    return;
  }
  if (proof.trim().length < 5) {
    res.status(400).json({ error: "Please provide a valid transaction ID or payment reference" });
    return;
  }
  try {
    const [deposit] = await db.insert(depositsTable).values({
      userId,
      amount: numAmount,
      method,
      proof: proof.trim(),
      status: "pending",
    }).returning();
    res.json({
      id: deposit.id,
      amount: deposit.amount,
      method: deposit.method,
      proof: deposit.proof,
      status: deposit.status,
      adminNote: deposit.adminNote,
      createdAt: deposit.createdAt.toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "Submit deposit error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
