import { Router, type IRouter, type Request, type Response } from "express";
import { db, usersTable, keysTable, depositsTable, settingsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { requireAdmin } from "../middlewares/auth";

const router: IRouter = Router();

router.use(requireAdmin as any);

router.get("/users", async (req: Request, res: Response) => {
  try {
    const users = await db.select({
      id: usersTable.id,
      username: usersTable.username,
      balance: usersTable.balance,
      isAdmin: usersTable.isAdmin,
      createdAt: usersTable.createdAt,
      lastIp: usersTable.lastIp,
      lastCountry: usersTable.lastCountry,
      lastSeenAt: usersTable.lastSeenAt,
    }).from(usersTable);
    res.json(users.map(u => ({
      ...u,
      createdAt: u.createdAt.toISOString(),
      lastSeenAt: u.lastSeenAt ? u.lastSeenAt.toISOString() : null,
    })));
  } catch (err) {
    req.log.error({ err }, "Admin get users error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/balance", async (req: Request, res: Response) => {
  const { userId, amount } = req.body;
  if (userId == null || amount == null) {
    res.status(400).json({ error: "userId and amount are required" });
    return;
  }
  const numAmount = Number(amount);
  if (isNaN(numAmount)) {
    res.status(400).json({ error: "amount must be a number (positive to add, negative to remove)" });
    return;
  }
  try {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, Number(userId))).limit(1);
    if (!user) {
      res.status(400).json({ error: "User not found" });
      return;
    }
    const newBalance = Math.max(0, user.balance + numAmount);
    const [updated] = await db.update(usersTable)
      .set({ balance: newBalance })
      .where(eq(usersTable.id, user.id))
      .returning();
    res.json({
      id: updated.id,
      username: updated.username,
      balance: updated.balance,
      isAdmin: updated.isAdmin,
      createdAt: updated.createdAt.toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "Admin update balance error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/keys", async (req: Request, res: Response) => {
  try {
    const keys = await db.select().from(keysTable);
    res.json(keys.map(k => ({
      id: k.id,
      keyValue: k.keyValue,
      productId: k.productId,
      isUsed: k.isUsed,
      createdAt: k.createdAt.toISOString(),
    })).reverse());
  } catch (err) {
    req.log.error({ err }, "Admin get keys error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/keys", async (req: Request, res: Response) => {
  const { keyValue, productId } = req.body;
  const validProducts = ["1day", "7day", "30day"];
  if (!keyValue || !productId) {
    res.status(400).json({ error: "keyValue and productId are required" });
    return;
  }
  if (!validProducts.includes(productId)) {
    res.status(400).json({ error: "productId must be: 1day, 7day, or 30day" });
    return;
  }
  if (keyValue.trim().length < 4) {
    res.status(400).json({ error: "Key value must be at least 4 characters" });
    return;
  }
  try {
    const [key] = await db.insert(keysTable).values({
      keyValue: keyValue.trim(),
      productId,
      isUsed: false,
    }).returning();
    res.json({
      id: key.id,
      keyValue: key.keyValue,
      productId: key.productId,
      isUsed: key.isUsed,
      createdAt: key.createdAt.toISOString(),
    });
  } catch (err: any) {
    if (err.code === "23505") {
      res.status(400).json({ error: "This key already exists" });
      return;
    }
    req.log.error({ err }, "Admin add key error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/keys/:id", async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid key ID" });
    return;
  }
  try {
    const [key] = await db.select().from(keysTable).where(eq(keysTable.id, id)).limit(1);
    if (!key) {
      res.status(400).json({ error: "Key not found" });
      return;
    }
    await db.delete(keysTable).where(eq(keysTable.id, id));
    res.json({ message: "Key deleted" });
  } catch (err) {
    req.log.error({ err }, "Admin delete key error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/deposits", async (req: Request, res: Response) => {
  try {
    const deposits = await db
      .select({
        id: depositsTable.id,
        userId: depositsTable.userId,
        username: usersTable.username,
        amount: depositsTable.amount,
        method: depositsTable.method,
        proof: depositsTable.proof,
        status: depositsTable.status,
        adminNote: depositsTable.adminNote,
        createdAt: depositsTable.createdAt,
      })
      .from(depositsTable)
      .leftJoin(usersTable, eq(depositsTable.userId, usersTable.id));
    res.json(deposits.map(d => ({
      ...d,
      createdAt: d.createdAt.toISOString(),
    })).reverse());
  } catch (err) {
    req.log.error({ err }, "Admin get deposits error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/deposits/:id/approve", async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid deposit ID" });
    return;
  }
  const { note } = req.body;
  try {
    const [deposit] = await db.select().from(depositsTable).where(eq(depositsTable.id, id)).limit(1);
    if (!deposit) {
      res.status(400).json({ error: "Deposit not found" });
      return;
    }
    if (deposit.status !== "pending") {
      res.status(400).json({ error: "Deposit already reviewed" });
      return;
    }
    await db.update(depositsTable).set({ status: "approved", adminNote: note || null, reviewedAt: new Date() }).where(eq(depositsTable.id, id));
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, deposit.userId)).limit(1);
    if (user) {
      await db.update(usersTable).set({ balance: user.balance + deposit.amount }).where(eq(usersTable.id, user.id));
    }
    res.json({ message: `Approved. $${deposit.amount} added to user balance.` });
  } catch (err) {
    req.log.error({ err }, "Admin approve deposit error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/deposits/:id/reject", async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid deposit ID" });
    return;
  }
  const { note } = req.body;
  try {
    const [deposit] = await db.select().from(depositsTable).where(eq(depositsTable.id, id)).limit(1);
    if (!deposit) {
      res.status(400).json({ error: "Deposit not found" });
      return;
    }
    if (deposit.status !== "pending") {
      res.status(400).json({ error: "Deposit already reviewed" });
      return;
    }
    await db.update(depositsTable).set({ status: "rejected", adminNote: note || null, reviewedAt: new Date() }).where(eq(depositsTable.id, id));
    res.json({ message: "Deposit rejected." });
  } catch (err) {
    req.log.error({ err }, "Admin reject deposit error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/settings", async (req: Request, res: Response) => {
  try {
    const rows = await db.select().from(settingsTable);
    const result: Record<string, string> = {};
    for (const row of rows) result[row.key] = row.value;
    res.json(result);
  } catch (err) {
    req.log.error({ err }, "Admin get settings error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/settings", async (req: Request, res: Response) => {
  const allowed = ["btcAddress", "ethAddress", "usdtAddress", "bankName", "bankAccount", "bankHolder", "bankNote", "bogIban", "tbcIban", "binanceId", "giftCardInfo"];
  const updates = req.body as Record<string, string>;
  const keys = Object.keys(updates).filter(k => allowed.includes(k));
  if (keys.length === 0) {
    res.status(400).json({ error: "No valid settings provided" });
    return;
  }
  try {
    for (const key of keys) {
      const value = String(updates[key] || "");
      await db.insert(settingsTable).values({ key, value }).onConflictDoUpdate({ target: settingsTable.key, set: { value, updatedAt: new Date() } });
    }
    const rows = await db.select().from(settingsTable);
    const result: Record<string, string> = {};
    for (const row of rows) result[row.key] = row.value;
    res.json(result);
  } catch (err) {
    req.log.error({ err }, "Admin update settings error");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/stats", async (req: Request, res: Response) => {
  try {
    const users = await db.select({ count: sql<number>`count(*)` }).from(usersTable);
    const keys = await db.select({ count: sql<number>`count(*)` }).from(keysTable).where(eq(keysTable.isUsed, false));
    const pendingDeposits = await db.select({ count: sql<number>`count(*)` }).from(depositsTable).where(eq(depositsTable.status, "pending"));
    res.json({
      totalUsers: Number(users[0]?.count ?? 0),
      availableKeys: Number(keys[0]?.count ?? 0),
      pendingDeposits: Number(pendingDeposits[0]?.count ?? 0),
    });
  } catch (err) {
    req.log.error({ err }, "Admin stats error");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
