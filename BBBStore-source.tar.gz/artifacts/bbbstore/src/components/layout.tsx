import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { LogOut, Loader2, KeyRound, Shield, LayoutDashboard, Menu, X, Send } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export function AppLayout({ children }: { children: React.ReactNode }) {
  const { user, logout, isLoggingOut, isLoading } = useAuth();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) return null;

  const navLinks = [
    { href: "/dashboard", label: "Dashboard", icon: <LayoutDashboard className="h-4 w-4" /> },
    ...(user.isAdmin ? [{ href: "/admin", label: "Admin Panel", icon: <Shield className="h-4 w-4" /> }] : []),
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col relative overflow-x-hidden">
      {/* Global background orbs */}
      <div className="fixed top-[-200px] left-[-100px] w-[600px] h-[600px] bg-primary/10 rounded-full blur-[120px] pointer-events-none -z-10" />
      <div className="fixed bottom-[-200px] right-[-100px] w-[500px] h-[500px] bg-accent/8 rounded-full blur-[100px] pointer-events-none -z-10" />

      {/* Navbar */}
      <header className="sticky top-0 z-40 w-full border-b border-white/5 bg-background/70 backdrop-blur-xl">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">

          {/* Left: logo + desktop nav */}
          <div className="flex items-center gap-6">
            <Link href="/dashboard" className="flex items-center gap-2.5 group">
              <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/30 group-hover:scale-105 group-hover:shadow-primary/50 transition-all">
                <KeyRound className="h-4 w-4 text-white" />
              </div>
              <span className="font-display font-black text-xl tracking-tight hidden sm:block">
                <span className="text-white">BBB</span>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">STORE</span>
              </span>
            </Link>

            <nav className="hidden md:flex items-center gap-1">
              {navLinks.map(link => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-1.5 ${
                    location === link.href
                      ? link.href === "/admin"
                        ? "bg-primary/20 text-primary shadow-sm"
                        : "bg-white/10 text-white shadow-sm"
                      : link.href === "/admin"
                        ? "text-muted-foreground hover:text-primary hover:bg-primary/10"
                        : "text-muted-foreground hover:text-white hover:bg-white/5"
                  }`}
                >
                  {link.icon}
                  {link.label}
                </Link>
              ))}
            </nav>
          </div>

          {/* Right */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex flex-col items-end">
              <span className="text-[10px] text-muted-foreground font-medium uppercase tracking-wider">Balance</span>
              <span className="font-display font-bold text-primary leading-none tracking-tight">
                {user.balance.toFixed(2)}
              </span>
            </div>
            <div className="h-8 w-[1px] bg-white/10 hidden sm:block" />
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-gradient-to-br from-primary/40 to-accent/30 border border-white/10 flex items-center justify-center font-bold text-sm text-white">
                {user.username.charAt(0).toUpperCase()}
              </div>
              <span className="text-sm font-medium hidden md:block">{user.username}</span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={logout}
              isLoading={isLoggingOut}
              className="text-muted-foreground hover:text-destructive hover:bg-destructive/10"
              title="Logout"
            >
              <LogOut className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-muted-foreground"
              onClick={() => setMobileMenuOpen(v => !v)}
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.15 }}
              className="md:hidden border-t border-white/5 bg-background/95 backdrop-blur-xl"
            >
              <nav className="container mx-auto px-4 py-3 flex flex-col gap-1">
                <div className="flex items-center justify-between px-3 py-2 mb-1 border-b border-white/5">
                  <span className="text-xs text-muted-foreground">Signed in as <span className="text-white font-semibold">{user.username}</span></span>
                  <span className="text-xs font-bold text-primary">{user.balance.toFixed(2)}</span>
                </div>
                {navLinks.map(link => (
                  <Link
                    key={link.href}
                    href={link.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`px-3 py-2.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${
                      location === link.href
                        ? link.href === "/admin" ? "bg-primary/20 text-primary" : "bg-white/10 text-white"
                        : link.href === "/admin" ? "text-yellow-400 hover:bg-primary/10" : "text-muted-foreground hover:text-white hover:bg-white/5"
                    }`}
                  >
                    {link.icon}
                    {link.label}
                    {link.href === "/admin" && (
                      <span className="ml-auto text-xs bg-primary/20 text-primary px-2 py-0.5 rounded-full">Admin</span>
                    )}
                  </Link>
                ))}
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main */}
      <main className="flex-1 container mx-auto px-4 py-8 relative">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
          {children}
        </motion.div>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 bg-background/60 backdrop-blur-xl mt-4">
        <div className="container mx-auto px-4 py-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          {/* Brand */}
          <div className="flex items-center gap-2.5">
            <div className="h-7 w-7 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <KeyRound className="h-3.5 w-3.5 text-white" />
            </div>
            <span className="font-display font-black text-sm">
              <span className="text-white">BBB</span>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">STORE</span>
            </span>
            <span className="text-xs text-muted-foreground hidden sm:block">— Premium Digital Keys</span>
          </div>

          {/* Telegram contact */}
          <a
            href="https://t.me/style0090"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#229ED9]/10 border border-[#229ED9]/20 text-[#229ED9] hover:bg-[#229ED9]/20 transition-all text-sm font-medium group"
          >
            <Send className="h-4 w-4 group-hover:translate-x-0.5 transition-transform" />
            Contact support on Telegram
          </a>

          <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} BBBStore. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
