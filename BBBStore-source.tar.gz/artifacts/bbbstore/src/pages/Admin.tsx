import React, { useState, useEffect } from "react";
import { AppLayout } from "@/components/layout";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import {
  useAdminGetUsers,
  useAdminUpdateBalance,
  useAdminGetKeys,
  useAdminAddKey,
  useAdminDeleteKey,
  useGetProducts
} from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { formatCurrency } from "@/lib/utils";
import { format } from "date-fns";
import {
  ShieldAlert, Users, KeySquare, Plus, Trash2, Banknote,
  ClipboardCheck, Settings, CheckCircle, XCircle, RefreshCw, Save
} from "lucide-react";
import { motion } from "framer-motion";

type DepositRequest = {
  id: number;
  userId: number;
  username: string | null;
  amount: number;
  method: string;
  proof: string;
  status: string;
  adminNote: string | null;
  createdAt: string;
};

type PaymentSettings = {
  btcAddress?: string;
  ethAddress?: string;
  usdtAddress?: string;
  bankName?: string;
  bankAccount?: string;
  bankHolder?: string;
  bankNote?: string;
  bogIban?: string;
  tbcIban?: string;
  binanceId?: string;
  giftCardInfo?: string;
};

type Tab = "users" | "keys" | "deposits" | "settings";

export default function Admin() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<Tab>("users");

  useEffect(() => {
    if (user && !user.isAdmin) setLocation("/dashboard");
  }, [user, setLocation]);

  if (!user || !user.isAdmin) return null;

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: "users", label: "Users", icon: <Users className="w-4 h-4" /> },
    { id: "keys", label: "Keys", icon: <KeySquare className="w-4 h-4" /> },
    { id: "deposits", label: "Deposits", icon: <ClipboardCheck className="w-4 h-4" /> },
    { id: "settings", label: "Settings", icon: <Settings className="w-4 h-4" /> },
  ];

  return (
    <AppLayout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold flex items-center gap-3 mb-1">
          <ShieldAlert className="w-8 h-8 text-primary" /> Admin Control Panel
        </h1>
        <p className="text-muted-foreground">Full control over users, keys, deposits, and payment settings.</p>
      </div>

      <div className="flex bg-black/20 p-1 rounded-xl border border-white/5 w-full mb-8 overflow-x-auto">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 px-4 py-2.5 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${activeTab === tab.id ? "bg-card text-foreground shadow-lg border border-white/5" : "text-muted-foreground hover:text-white"}`}
          >
            <span className="flex items-center justify-center gap-2">{tab.icon} {tab.label}</span>
          </button>
        ))}
      </div>

      <motion.div key={activeTab} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.2 }}>
        {activeTab === "users" && <UsersManager />}
        {activeTab === "keys" && <KeysManager />}
        {activeTab === "deposits" && <DepositsManager />}
        {activeTab === "settings" && <PaymentSettingsManager />}
      </motion.div>
    </AppLayout>
  );
}

function UsersManager() {
  const { data: users = [], isLoading } = useAdminGetUsers();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [balanceAmount, setBalanceAmount] = useState("");
  const [showForm, setShowForm] = useState(false);

  const updateBalanceMutation = useAdminUpdateBalance({
    mutation: {
      onSuccess: () => {
        toast({ title: "Balance updated successfully" });
        queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
        setShowForm(false);
        setBalanceAmount("");
      },
      onError: (err: any) => {
        toast({ title: "Update failed", description: err?.response?.data?.error || "Failed", variant: "destructive" });
      }
    }
  });

  const handleUpdateBalance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser || !balanceAmount) return;
    updateBalanceMutation.mutate({ data: { userId: selectedUser.id, amount: Number(balanceAmount) } });
  };

  return (
    <div className="space-y-4">
      {showForm && selectedUser && (
        <Card className="bg-card/50 border-white/5 p-6">
          <h3 className="font-semibold mb-4 flex items-center gap-2"><Banknote className="w-4 h-4 text-primary" /> Update Balance — <span className="text-primary">{selectedUser.username}</span></h3>
          <form onSubmit={handleUpdateBalance} className="flex gap-3 items-end">
            <div className="flex-1 space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Amount (positive to add, negative to remove)</label>
              <Input type="number" step="0.01" placeholder="e.g. 50 or -10" value={balanceAmount} onChange={e => setBalanceAmount(e.target.value)} required />
              <p className="text-xs text-muted-foreground">Current: {formatCurrency(selectedUser.balance)}</p>
            </div>
            <Button type="submit" disabled={updateBalanceMutation.isPending}>
              {updateBalanceMutation.isPending ? <RefreshCw className="w-4 h-4 animate-spin" /> : "Apply"}
            </Button>
            <Button type="button" variant="ghost" onClick={() => setShowForm(false)}>Cancel</Button>
          </form>
        </Card>
      )}

      <Card className="bg-card/50 backdrop-blur-sm border-white/5 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-black/20 text-muted-foreground border-b border-white/5">
              <tr>
                <th className="px-4 py-4 font-medium">ID</th>
                <th className="px-4 py-4 font-medium">Username</th>
                <th className="px-4 py-4 font-medium">Role</th>
                <th className="px-4 py-4 font-medium">Balance</th>
                <th className="px-4 py-4 font-medium">IP Address</th>
                <th className="px-4 py-4 font-medium">Location</th>
                <th className="px-4 py-4 font-medium">Last Seen</th>
                <th className="px-4 py-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {isLoading ? (
                <tr><td colSpan={8} className="p-8 text-center animate-pulse">Loading users...</td></tr>
              ) : users.map((u: any) => (
                <tr key={u.id} className="hover:bg-white/[0.02] transition-colors">
                  <td className="px-4 py-4 text-muted-foreground">#{u.id}</td>
                  <td className="px-4 py-4 font-medium">{u.username}</td>
                  <td className="px-4 py-4">{u.isAdmin ? <Badge variant="secondary">Admin</Badge> : <Badge variant="outline">User</Badge>}</td>
                  <td className="px-4 py-4 font-mono font-bold text-primary">{formatCurrency(u.balance)}</td>
                  <td className="px-4 py-4">
                    {u.lastIp ? (
                      <code className="text-xs bg-black/30 border border-white/10 px-2 py-1 rounded text-cyan-400">{u.lastIp}</code>
                    ) : <span className="text-muted-foreground text-xs">—</span>}
                  </td>
                  <td className="px-4 py-4">
                    {u.lastCountry ? (
                      <span className="text-sm font-medium text-white">{u.lastCountry}</span>
                    ) : <span className="text-muted-foreground text-xs">—</span>}
                  </td>
                  <td className="px-4 py-4 text-muted-foreground text-xs">
                    {u.lastSeenAt ? format(new Date(u.lastSeenAt), "MMM d, HH:mm") : "Never"}
                  </td>
                  <td className="px-4 py-4 text-right">
                    <Button variant="outline" size="sm" onClick={() => { setSelectedUser(u); setShowForm(true); setBalanceAmount(""); }}>
                      <Banknote className="w-4 h-4 mr-1" /> Balance
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

const GEL_PRODUCT_OPTIONS = [
  { id: "king-ios-1day",  name: "🇬🇪 KING IOS — 1 Day (₾15)" },
  { id: "king-ios-7day",  name: "🇬🇪 KING IOS — 1 Week (₾40)" },
  { id: "king-ios-30day", name: "🇬🇪 KING IOS — 1 Month (₾80)" },
  { id: "oasis-1day",     name: "🇬🇪 Oasis — 1 Day (₾15)" },
  { id: "oasis-7day",     name: "🇬🇪 Oasis — 1 Week (₾40)" },
  { id: "oasis-30day",    name: "🇬🇪 Oasis — 1 Month (₾80)" },
  { id: "dolphin-1day",   name: "🇬🇪 Dolphin — 1 Day (₾10)" },
  { id: "dolphin-7day",   name: "🇬🇪 Dolphin — 1 Week (₾35)" },
  { id: "dolphin-30day",  name: "🇬🇪 Dolphin — 1 Month (₾60)" },
  { id: "ios-star-1day",  name: "🇬🇪 Ios Star — 1 Day (₾10)" },
  { id: "ios-star-7day",  name: "🇬🇪 Ios Star — 1 Week (₾35)" },
  { id: "ios-star-30day", name: "🇬🇪 Ios Star — 1 Month (₾60)" },
  { id: "ios-zoon-1day",  name: "🇬🇪 Ios Zoon — 1 Day (₾10)" },
  { id: "ios-zoon-7day",  name: "🇬🇪 Ios Zoon — 1 Week (₾35)" },
  { id: "ios-zoon-30day", name: "🇬🇪 Ios Zoon — 1 Month (₾60)" },
];

function KeysManager() {
  const { data: keys = [], isLoading: loadingKeys } = useAdminGetKeys();
  const { data: products = [] } = useGetProducts();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [keyValue, setKeyValue] = useState("");
  const [productId, setProductId] = useState("");

  const addKeyMutation = useAdminAddKey({
    mutation: {
      onSuccess: () => {
        toast({ title: "Key added to inventory" });
        queryClient.invalidateQueries({ queryKey: ["/api/admin/keys"] });
        setShowForm(false);
        setKeyValue("");
        setProductId("");
      },
      onError: (err: any) => {
        toast({ title: "Failed to add key", description: err?.response?.data?.error || "Error", variant: "destructive" });
      }
    }
  });

  const deleteKeyMutation = useAdminDeleteKey({
    mutation: {
      onSuccess: () => {
        toast({ title: "Key deleted" });
        queryClient.invalidateQueries({ queryKey: ["/api/admin/keys"] });
      }
    }
  });

  const handleAddKey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!keyValue || !productId) return;
    addKeyMutation.mutate({ data: { keyValue, productId } });
  };

  return (
    <div className="space-y-4">
      {showForm && (
        <Card className="bg-card/50 border-white/5 p-6">
          <h3 className="font-semibold mb-4 flex items-center gap-2"><Plus className="w-4 h-4 text-primary" /> Add New Key</h3>
          <form onSubmit={handleAddKey} className="flex gap-3 flex-wrap items-end">
            <div className="space-y-1 flex-1 min-w-[160px]">
              <label className="text-xs font-medium text-muted-foreground">Product</label>
              <select value={productId} onChange={e => setProductId(e.target.value)}
                className="flex h-10 w-full rounded-xl border border-input bg-background/50 px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                required>
                <option value="" disabled>Select product</option>
                <optgroup label="— USD Products —">
                  {products.map(p => <option key={p.id} value={p.id}>{p.name} (${p.price})</option>)}
                </optgroup>
                <optgroup label="— Georgian Products (GEL) —">
                  {GEL_PRODUCT_OPTIONS.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </optgroup>
              </select>
            </div>
            <div className="space-y-1 flex-[2] min-w-[200px]">
              <label className="text-xs font-medium text-muted-foreground">Key Value</label>
              <Input type="text" placeholder="XXXX-XXXX-XXXX-XXXX" value={keyValue} onChange={e => setKeyValue(e.target.value)} required />
            </div>
            <Button type="submit" disabled={addKeyMutation.isPending}>
              {addKeyMutation.isPending ? <RefreshCw className="w-4 h-4 animate-spin" /> : "Add Key"}
            </Button>
            <Button type="button" variant="ghost" onClick={() => setShowForm(false)}>Cancel</Button>
          </form>
        </Card>
      )}

      <Card className="bg-card/50 backdrop-blur-sm border-white/5 overflow-hidden">
        <div className="p-4 flex items-center justify-between border-b border-white/5 bg-black/10">
          <h3 className="font-medium">Key Inventory ({keys.filter(k => !k.isUsed).length} available)</h3>
          <Button onClick={() => setShowForm(v => !v)} size="sm">
            <Plus className="w-4 h-4 mr-1" /> Add Key
          </Button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-black/20 text-muted-foreground border-b border-white/5">
              <tr>
                <th className="px-6 py-4 font-medium">Product</th>
                <th className="px-6 py-4 font-medium">Key</th>
                <th className="px-6 py-4 font-medium">Status</th>
                <th className="px-6 py-4 font-medium">Added</th>
                <th className="px-6 py-4 font-medium text-right">Delete</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {loadingKeys ? (
                <tr><td colSpan={5} className="p-8 text-center animate-pulse">Loading...</td></tr>
              ) : keys.map(k => (
                <tr key={k.id} className="hover:bg-white/[0.02] transition-colors">
                  <td className="px-6 py-4 font-medium">{k.productId}</td>
                  <td className="px-6 py-4"><code className="px-2 py-1 rounded bg-black/30 text-primary border border-primary/20 text-xs">{k.keyValue}</code></td>
                  <td className="px-6 py-4">
                    {k.isUsed
                      ? <span className="text-xs px-2.5 py-1 rounded-full bg-red-500/10 text-red-400 border border-red-500/20 font-medium">Used</span>
                      : <span className="text-xs px-2.5 py-1 rounded-full bg-green-500/10 text-green-400 border border-green-500/20 font-medium">Available</span>
                    }
                  </td>
                  <td className="px-6 py-4 text-muted-foreground">{format(new Date(k.createdAt), "MMM d, yyyy")}</td>
                  <td className="px-6 py-4 text-right">
                    <Button variant="ghost" size="icon"
                      onClick={() => { if (confirm("Delete this key?")) deleteKeyMutation.mutate({ id: k.id }); }}
                      className="text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                      disabled={deleteKeyMutation.isPending}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </td>
                </tr>
              ))}
              {keys.length === 0 && !loadingKeys && <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">No keys in inventory.</td></tr>}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function DepositsManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [deposits, setDeposits] = useState<DepositRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionNote, setActionNote] = useState<Record<number, string>>({});
  const [processing, setProcessing] = useState<number | null>(null);

  const fetchDeposits = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/deposits", { credentials: "include" });
      const data = await res.json();
      if (Array.isArray(data)) setDeposits(data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchDeposits(); }, []);

  const handleAction = async (id: number, action: "approve" | "reject") => {
    setProcessing(id);
    try {
      const res = await fetch(`/api/admin/deposits/${id}/${action}`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ note: actionNote[id] || "" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed");
      toast({ title: action === "approve" ? "Deposit approved! Balance added." : "Deposit rejected." });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      fetchDeposits();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setProcessing(null);
    }
  };

  const getStatusColor = (status: string) => {
    if (status === "approved") return "bg-green-500/10 text-green-400 border-green-500/20";
    if (status === "rejected") return "bg-red-500/10 text-red-400 border-red-500/20";
    return "bg-yellow-500/10 text-yellow-400 border-yellow-500/20";
  };

  return (
    <Card className="bg-card/50 backdrop-blur-sm border-white/5 overflow-hidden">
      <div className="p-4 flex items-center justify-between border-b border-white/5 bg-black/10">
        <h3 className="font-medium">Deposit Requests</h3>
        <Button variant="ghost" size="sm" onClick={fetchDeposits}><RefreshCw className="w-4 h-4 mr-1" /> Refresh</Button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="bg-black/20 text-muted-foreground border-b border-white/5">
            <tr>
              <th className="px-4 py-4 font-medium">User</th>
              <th className="px-4 py-4 font-medium">Amount</th>
              <th className="px-4 py-4 font-medium">Method</th>
              <th className="px-4 py-4 font-medium">Proof</th>
              <th className="px-4 py-4 font-medium">Status</th>
              <th className="px-4 py-4 font-medium">Date</th>
              <th className="px-4 py-4 font-medium text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {loading ? (
              <tr><td colSpan={7} className="p-8 text-center animate-pulse">Loading...</td></tr>
            ) : deposits.map(d => (
              <tr key={d.id} className="hover:bg-white/[0.02] transition-colors">
                <td className="px-4 py-4 font-medium">{d.username || `#${d.userId}`}</td>
                <td className="px-4 py-4 font-bold text-primary font-mono">{formatCurrency(d.amount)}</td>
                <td className="px-4 py-4 uppercase text-xs font-bold text-muted-foreground">{d.method}</td>
                <td className="px-4 py-4 max-w-[180px]">
                  <code className="text-xs text-muted-foreground truncate block">{d.proof}</code>
                </td>
                <td className="px-4 py-4">
                  <span className={`text-xs px-2.5 py-1 rounded-full border font-medium capitalize ${getStatusColor(d.status)}`}>{d.status}</span>
                </td>
                <td className="px-4 py-4 text-muted-foreground text-xs">{format(new Date(d.createdAt), "MMM d, HH:mm")}</td>
                <td className="px-4 py-4 text-right">
                  {d.status === "pending" ? (
                    <div className="flex items-center gap-1 justify-end">
                      <Input
                        placeholder="Note (optional)"
                        className="h-8 text-xs w-28 hidden md:block"
                        value={actionNote[d.id] || ""}
                        onChange={e => setActionNote(prev => ({ ...prev, [d.id]: e.target.value }))}
                      />
                      <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white h-8 px-2"
                        onClick={() => handleAction(d.id, "approve")} disabled={processing === d.id}>
                        <CheckCircle className="w-3.5 h-3.5" />
                      </Button>
                      <Button size="sm" variant="ghost" className="text-destructive hover:bg-destructive/10 h-8 px-2"
                        onClick={() => handleAction(d.id, "reject")} disabled={processing === d.id}>
                        <XCircle className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  ) : (
                    <span className="text-xs text-muted-foreground">{d.adminNote || "—"}</span>
                  )}
                </td>
              </tr>
            ))}
            {deposits.length === 0 && !loading && <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">No deposit requests yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function PaymentSettingsManager() {
  const { toast } = useToast();
  const [settings, setSettings] = useState<PaymentSettings>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/admin/settings", { credentials: "include" }).then(r => r.json()).then(data => { setSettings(data); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed");
      setSettings(data);
      toast({ title: "Payment settings saved!" });
    } catch (err: any) {
      toast({ title: "Failed to save", description: err.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const set = (key: keyof PaymentSettings) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setSettings(prev => ({ ...prev, [key]: e.target.value }));

  if (loading) return <div className="p-8 text-center animate-pulse">Loading settings...</div>;

  return (
    <form onSubmit={handleSave} className="space-y-6">
      <Card className="bg-card/50 border-white/5 p-6 space-y-5">
        <h3 className="font-semibold text-lg flex items-center gap-2"><svg viewBox="0 0 24 24" fill="none" className="w-5 h-5 text-orange-400" stroke="currentColor" strokeWidth={2}><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.31-8.86c-1.77-.45-2.34-.94-2.34-1.67 0-.84.79-1.43 2.1-1.43 1.38 0 1.9.66 1.94 1.64h1.71c-.05-1.34-.87-2.57-2.49-2.97V5H10.9v1.69c-1.51.32-2.72 1.3-2.72 2.81 0 1.79 1.49 2.69 3.66 3.21 1.95.46 2.34 1.15 2.34 1.87 0 .53-.39 1.39-2.1 1.39-1.6 0-2.23-.72-2.32-1.64H8.04c.1 1.7 1.36 2.66 2.86 2.97V19h2.34v-1.67c1.52-.29 2.72-1.16 2.73-2.77-.01-2.2-1.9-2.96-3.66-3.42z"/></svg> Crypto Addresses</h3>
        <div className="grid md:grid-cols-3 gap-4">
          {[
            { key: "btcAddress" as const, label: "BTC Address", placeholder: "bc1q..." },
            { key: "ethAddress" as const, label: "ETH Address", placeholder: "0x..." },
            { key: "usdtAddress" as const, label: "USDT Address (TRC20/ERC20)", placeholder: "T..." },
          ].map(({ key, label, placeholder }) => (
            <div key={key} className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">{label}</label>
              <Input placeholder={placeholder} value={settings[key] || ""} onChange={set(key)} />
            </div>
          ))}
        </div>
      </Card>

      <Card className="bg-card/50 border-white/5 p-6 space-y-5">
        <h3 className="font-semibold text-lg flex items-center gap-2"><Landmark className="w-5 h-5 text-blue-400" /> Bank Transfer Details</h3>
        <div className="grid md:grid-cols-2 gap-4">
          {[
            { key: "bankName" as const, label: "Bank Name", placeholder: "e.g. Chase Bank" },
            { key: "bankHolder" as const, label: "Account Holder", placeholder: "Full name" },
            { key: "bankAccount" as const, label: "Account Number / IBAN", placeholder: "1234567890" },
            { key: "bankNote" as const, label: "Note for Users", placeholder: "e.g. Include your username in the reference" },
          ].map(({ key, label, placeholder }) => (
            <div key={key} className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">{label}</label>
              <Input placeholder={placeholder} value={settings[key] || ""} onChange={set(key)} />
            </div>
          ))}
        </div>
      </Card>

      <Card className="bg-card/50 border-white/5 p-6 space-y-5">
        <h3 className="font-semibold text-lg flex items-center gap-2">🇬🇪 Georgian Bank IBANs</h3>
        <p className="text-xs text-muted-foreground">These IBANs are shown only to users visiting from a Georgian IP address.</p>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-xs font-medium text-muted-foreground">Bank of Georgia IBAN</label>
            <Input placeholder="GE00BG0000000000000000" value={settings.bogIban || ""} onChange={set("bogIban")} />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-medium text-muted-foreground">TBC Bank IBAN</label>
            <Input placeholder="GE00TB0000000000000000" value={settings.tbcIban || ""} onChange={set("tbcIban")} />
          </div>
        </div>
      </Card>

      <Card className="bg-card/50 border-white/5 p-6 space-y-5">
        <h3 className="font-semibold text-lg flex items-center gap-2">🌍 International Deposit Options</h3>
        <p className="text-xs text-muted-foreground">These are shown to users outside Georgia.</p>
        <div className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-medium text-muted-foreground">Binance ID</label>
            <Input placeholder="e.g. 123456789" value={settings.binanceId || ""} onChange={set("binanceId")} />
            <p className="text-xs text-muted-foreground">Users will send crypto to this Binance Pay ID.</p>
          </div>
          <div className="space-y-1">
            <label className="text-xs font-medium text-muted-foreground">Gift Card Instructions</label>
            <Input placeholder="e.g. Send Amazon/Google Play gift card code to @admin on Telegram" value={settings.giftCardInfo || ""} onChange={set("giftCardInfo")} />
            <p className="text-xs text-muted-foreground">Instructions shown to users who choose to pay with a gift card.</p>
          </div>
        </div>
      </Card>

      <Button type="submit" size="lg" className="w-full" disabled={saving}>
        {saving ? <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Saving...</> : <><Save className="w-4 h-4 mr-2" /> Save Payment Settings</>}
      </Button>
    </form>
  );
}

function Landmark({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <line x1="3" y1="22" x2="21" y2="22" /><line x1="6" y1="18" x2="6" y2="11" /><line x1="10" y1="18" x2="10" y2="11" /><line x1="14" y1="18" x2="14" y2="11" /><line x1="18" y1="18" x2="18" y2="11" /><polygon points="12 2 20 7 4 7" />
    </svg>
  );
}
