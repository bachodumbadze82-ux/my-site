import React, { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Store } from "lucide-react";
import { motion } from "framer-motion";

export default function Register() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { register, isRegistering, user } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (user) {
      setLocation("/dashboard");
    }
  }, [user, setLocation]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) return;
    register({ username, password });
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row-reverse bg-background">
      {/* Right side branding */}
      <div className="hidden md:flex flex-1 relative bg-muted items-center justify-center overflow-hidden border-l border-white/5">
        <img 
          src={`${import.meta.env.BASE_URL}images/auth-bg.png`} 
          alt="Abstract tech background" 
          className="absolute inset-0 w-full h-full object-cover opacity-60 scale-x-[-1]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
        <div className="relative z-10 p-12 max-w-xl">
          <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-2xl shadow-primary/30 mb-8">
            <Store className="h-8 w-8 text-primary-foreground" />
          </div>
          <h1 className="text-5xl font-display font-bold text-white mb-4 leading-tight">
            Join The <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-cyan-400">
              Elite Network
            </span>
          </h1>
          <p className="text-lg text-muted-foreground">
            Create an account instantly and get access to the most exclusive digital products on the market.
          </p>
        </div>
      </div>

      {/* Left side form */}
      <div className="flex-1 flex items-center justify-center p-8 relative">
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none md:hidden">
          <div className="absolute top-[-20%] left-[-10%] w-[300px] h-[300px] bg-primary/20 rounded-full blur-[100px]" />
        </div>
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4 }}
          className="w-full max-w-md relative z-10 glass-panel rounded-3xl p-8 sm:p-10"
        >
          <div className="flex justify-center mb-8 md:hidden">
            <img 
              src={`${import.meta.env.BASE_URL}images/logo.png`} 
              alt="BBBStore Logo" 
              className="h-16 w-16 object-contain"
            />
          </div>

          <div className="text-center mb-8">
            <h2 className="text-3xl font-display font-bold tracking-tight mb-2">Create Account</h2>
            <p className="text-muted-foreground">Join BBBStore today</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground ml-1">Choose a Username</label>
              <Input
                type="text"
                placeholder="johndoe123"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                minLength={3}
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground ml-1">Create Password</label>
              <Input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
              />
            </div>

            <Button type="submit" className="w-full h-12 text-md mt-2" isLoading={isRegistering}>
              Register Now
            </Button>
          </form>

          <p className="mt-8 text-center text-sm text-muted-foreground">
            Already have an account?{" "}
            <Link href="/" className="text-primary font-medium hover:underline">
              Log in instead
            </Link>
          </p>
        </motion.div>
      </div>
    </div>
  );
}
