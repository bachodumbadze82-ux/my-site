import React, { useState, useEffect } from "react";
import { AppLayout } from "@/components/layout";
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useGetProducts, usePurchaseProduct, useGetPurchaseHistory } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { KeyRound, ShoppingCart, Clock, Wallet, CheckCircle2, Copy, PlusCircle, Send, RefreshCw } from "lucide-react";
import { motion } from "framer-motion";

const GEL_CATEGORIES = [
  { id: "king-ios",  name: "KING IOS",  tier: "A" },
  { id: "oasis",     name: "Oasis",     tier: "A" },
  { id: "dolphin",   name: "Dolphin",   tier: "B" },
  { id: "ios-star",  name: "Ios Star",  tier: "B" },
  { id: "ios-zoon",  name: "Ios Zoon",  tier: "B" },
];

const GEL_DURATIONS = [
  { id: "1day",  label: "1 Day",   tierA: 15, tierB: 10 },
  { id: "7day",  label: "1 Week",  tierA: 40, tierB: 35 },
  { id: "30day", label: "1 Month", tierA: 80, tierB: 60 },
];

function getGelPrice(tier: string, durId: string): number {
  const dur = GEL_DURATIONS.find(d => d.id === durId)!;
  return tier === "A" ? dur.tierA : dur.tierB;
}

type PaymentInfo = {
  bogIban: string;
  tbcIban: string;
  btcAddress: string;
  ethAddress: string;
  usdtAddress: string;
  bankName: string;
  bankAccount: string;
  bankHolder: string;
  bankNote: string;
  binanceId: string;
  giftCardInfo: string;
};

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [isGeorgian, setIsGeorgian] = useState<boolean | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [purchasing, setPurchasing] = useState<string | null>(null);

  const [paymentInfo, setPaymentInfo] = useState<PaymentInfo | null>(null);
  const [showDeposit, setShowDeposit] = useState(false);
  const [selectedBank, setSelectedBank] = useState<"bog" | "tbc">("bog");
  const [selectedIntlMethod, setSelectedIntlMethod] = useState<"binance" | "btc" | "eth" | "usdt" | "giftcard">("binance");
  const [depositAmount, setDepositAmount] = useState("");
  const [depositProof, setDepositProof] = useState("");
  const [submittingDeposit, setSubmittingDeposit] = useState(false);

  const { data: products = [], isLoading: loadingProducts } = useGetProducts();
  const { data: history = [], isLoading: loadingHistory } = useGetPurchaseHistory();

  const purchaseMutation = usePurchaseProduct({
    mutation: {
      onSuccess: (data) => {
        toast({ title: "Purchase Successful!", description: `Your key: ${data.key}` });
        queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
        queryClient.invalidateQueries({ queryKey: ["/api/store/history"] });
        setPurchasing(null);
      },
      onError: (error: any) => {
        toast({ title: "Purchase Failed", description: error?.response?.data?.error || "Could not complete purchase.", variant: "destructive" });
        setPurchasing(null);
      }
    }
  });

  useEffect(() => {
    fetch("/api/store/geo")
      .then(r => r.json())
      .then(data => setIsGeorgian(data.isGeorgian === true))
      .catch(() => setIsGeorgian(false));
    fetch("/api/store/payment-info")
      .then(r => r.json())
      .then(data => setPaymentInfo(data))
      .catch(() => {});
  }, []);

  const handlePurchase = (productId: string) => {
    if (!confirm("Confirm purchase?")) return;
    setPurchasing(productId);
    purchaseMutation.mutate({ data: { productId } });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied!" });
  };

  const handleSubmitDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!depositAmount || !depositProof) return;
    setSubmittingDeposit(true);
    const method = isGeorgian ? selectedBank : selectedIntlMethod;
    try {
      const res = await fetch("/api/store/deposits", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: Number(depositAmount), method, proof: depositProof }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed");
      toast({ title: "Deposit request sent!", description: "Admin will review and credit your balance shortly." });
      setDepositAmount("");
      setDepositProof("");
      setShowDeposit(false);
    } catch (err: any) {
      toast({ title: "Failed", description: err.message, variant: "destructive" });
    } finally {
      setSubmittingDeposit(false);
    }
  };

  const formatBalance = (bal: number) => isGeorgian ? `₾${bal.toFixed(2)}` : `$${bal.toFixed(2)}`;
  const selectedIban = selectedBank === "bog" ? paymentInfo?.bogIban : paymentInfo?.tbcIban;
  const selectedBankName = selectedBank === "bog" ? "Bank of Georgia" : "TBC Bank";
  const selectedCat = GEL_CATEGORIES.find(c => c.id === selectedCategory);
  const containerVariants = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.08 } } };
  const itemVariants = { hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0 } };

  return (
    <AppLayout>
      <div className="space-y-10 pb-10">

        {/* Balance Banner */}
        <section className="flex flex-col md:flex-row gap-6 items-center justify-between rounded-3xl p-8 border border-white/5 bg-card/40 backdrop-blur relative overflow-hidden">
          <div className="absolute right-0 top-0 w-64 h-64 bg-primary/20 blur-[80px] rounded-full -z-10" />
          <div className="flex-1">
            <Badge variant="outline" className="mb-4 bg-background/50 backdrop-blur">
              <CheckCircle2 className="w-3 h-3 mr-1 text-green-400" /> System Operational
            </Badge>
            <h1 className="text-4xl font-bold mb-2">Store Dashboard</h1>
            <p className="text-muted-foreground text-lg max-w-xl">Purchase premium access keys instantly.</p>
          </div>
          <div className="flex-shrink-0 bg-background/80 backdrop-blur-xl border border-white/10 rounded-2xl p-6 min-w-[280px] shadow-2xl shadow-black/50 text-center">
            <div className="inline-flex items-center justify-center p-3 bg-primary/10 rounded-full mb-4">
              <Wallet className="w-8 h-8 text-primary" />
            </div>
            <p className="text-sm text-muted-foreground font-medium mb-1">Available Balance</p>
            <h2 className="text-5xl font-bold text-white tracking-tight">{formatBalance(user?.balance || 0)}</h2>
            {isGeorgian !== null && (
              <Button
                size="sm"
                variant="outline"
                className="mt-4 w-full border-primary/30 text-primary hover:bg-primary/10"
                onClick={() => setShowDeposit(v => !v)}
              >
                <PlusCircle className="w-4 h-4 mr-2" /> {showDeposit ? "Close" : "Add Balance"}
              </Button>
            )}
          </div>
        </section>

        {/* Georgian Deposit Section */}
        {isGeorgian && showDeposit && (
          <motion.section
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-2xl border border-white/10 bg-card/40 backdrop-blur overflow-hidden"
          >
            <div className="p-5 border-b border-white/5 flex items-center justify-between">
              <h2 className="text-lg font-bold flex items-center gap-2">
                🇬🇪 <span>Balance Top-up</span>
              </h2>
              {/* Bank chooser */}
              <div className="flex gap-2">
                {(["bog", "tbc"] as const).map(bank => (
                  <button
                    key={bank}
                    onClick={() => setSelectedBank(bank)}
                    className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all border ${
                      selectedBank === bank
                        ? "bg-primary text-white border-primary shadow-md"
                        : "bg-white/5 text-muted-foreground border-white/10 hover:text-white hover:bg-white/10"
                    }`}
                  >
                    {bank === "bog" ? "Bank of Georgia" : "TBC Bank"}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6 p-6">
              {/* IBAN display */}
              <div className="space-y-4">
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Transfer Details</h3>
                {selectedIban ? (
                  <div className="bg-black/30 rounded-xl p-4 border border-white/10 space-y-3">
                    <p className="text-xs text-muted-foreground font-medium uppercase">{selectedBankName} IBAN</p>
                    <div className="flex items-center gap-3">
                      <code className="text-sm text-primary break-all flex-1 font-mono">{selectedIban}</code>
                      <button
                        onClick={() => copyToClipboard(selectedIban)}
                        className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors flex-shrink-0"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-xs text-yellow-400 bg-yellow-500/10 rounded-lg p-2">
                      Include your username <span className="font-bold">"{user?.username}"</span> in the transfer note.
                    </p>
                  </div>
                ) : (
                  <div className="bg-black/30 rounded-xl p-4 border border-white/10 text-muted-foreground text-sm">
                    Admin hasn't set the {selectedBankName} IBAN yet.
                  </div>
                )}
              </div>

              {/* Submit form */}
              <form onSubmit={handleSubmitDeposit} className="space-y-4">
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Submit Request</h3>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Amount (GEL ₾)</label>
                  <Input
                    type="number"
                    step="1"
                    min="1"
                    placeholder="e.g. 40"
                    value={depositAmount}
                    onChange={e => setDepositAmount(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Transfer Reference / Receipt Number</label>
                  <Input
                    type="text"
                    placeholder="e.g. TXN-123456"
                    value={depositProof}
                    onChange={e => setDepositProof(e.target.value)}
                    required
                  />
                </div>
                <Button type="submit" className="w-full" disabled={submittingDeposit}>
                  {submittingDeposit
                    ? <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Sending...</>
                    : <><Send className="w-4 h-4 mr-2" /> Send Request</>
                  }
                </Button>
                <p className="text-xs text-muted-foreground text-center">Admin will verify and add your balance shortly</p>
              </form>
            </div>
          </motion.section>
        )}

        {/* International Deposit Section */}
        {isGeorgian === false && showDeposit && (
          <motion.section
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-2xl border border-white/10 bg-card/40 backdrop-blur overflow-hidden"
          >
            <div className="p-5 border-b border-white/5">
              <h2 className="text-lg font-bold flex items-center gap-2">🌍 <span>Add Balance</span></h2>
              <p className="text-xs text-muted-foreground mt-1">Choose your preferred payment method below</p>
            </div>

            {/* Method Tabs */}
            <div className="flex flex-wrap gap-2 p-4 border-b border-white/5">
              {([
                { id: "binance", label: "💛 Binance ID" },
                { id: "btc",     label: "₿ Bitcoin" },
                { id: "eth",     label: "⟠ Ethereum" },
                { id: "usdt",    label: "💵 USDT" },
                { id: "giftcard",label: "🎁 Gift Card" },
              ] as const).map(m => (
                <button
                  key={m.id}
                  onClick={() => setSelectedIntlMethod(m.id)}
                  className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all border ${
                    selectedIntlMethod === m.id
                      ? "bg-primary text-white border-primary shadow-md"
                      : "bg-white/5 text-muted-foreground border-white/10 hover:text-white hover:bg-white/10"
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>

            <div className="grid md:grid-cols-2 gap-6 p-6">
              {/* Left: payment info */}
              <div className="space-y-4">
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Payment Details</h3>

                {selectedIntlMethod === "binance" && (
                  <div className="bg-black/30 rounded-xl p-4 border border-yellow-500/20 space-y-3">
                    <p className="text-xs text-yellow-400 font-semibold uppercase">Binance Pay ID</p>
                    {paymentInfo?.binanceId ? (
                      <>
                        <div className="flex items-center gap-3">
                          <code className="text-lg text-yellow-300 font-mono font-bold flex-1">{paymentInfo.binanceId}</code>
                          <button onClick={() => copyToClipboard(paymentInfo.binanceId)} className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
                            <Copy className="w-4 h-4" />
                          </button>
                        </div>
                        <p className="text-xs text-muted-foreground">Open Binance app → Pay → Send → Enter this ID</p>
                      </>
                    ) : (
                      <p className="text-sm text-muted-foreground">Binance ID not set yet. Contact admin via Telegram.</p>
                    )}
                  </div>
                )}

                {(selectedIntlMethod === "btc" || selectedIntlMethod === "eth" || selectedIntlMethod === "usdt") && (
                  <div className="bg-black/30 rounded-xl p-4 border border-primary/20 space-y-3">
                    <p className="text-xs text-primary font-semibold uppercase">
                      {selectedIntlMethod === "btc" ? "Bitcoin (BTC) Address" : selectedIntlMethod === "eth" ? "Ethereum (ETH) Address" : "USDT Address (TRC20/ERC20)"}
                    </p>
                    {(() => {
                      const addr = selectedIntlMethod === "btc" ? paymentInfo?.btcAddress : selectedIntlMethod === "eth" ? paymentInfo?.ethAddress : paymentInfo?.usdtAddress;
                      return addr ? (
                        <>
                          <div className="flex items-center gap-3">
                            <code className="text-xs text-primary break-all flex-1 font-mono">{addr}</code>
                            <button onClick={() => copyToClipboard(addr)} className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors flex-shrink-0">
                              <Copy className="w-4 h-4" />
                            </button>
                          </div>
                          <p className="text-xs text-yellow-400 bg-yellow-500/10 rounded-lg p-2">⚠️ Send only {selectedIntlMethod.toUpperCase()} to this address. Wrong network = lost funds.</p>
                        </>
                      ) : (
                        <p className="text-sm text-muted-foreground">Address not set yet. Contact admin via Telegram.</p>
                      );
                    })()}
                  </div>
                )}

                {selectedIntlMethod === "giftcard" && (
                  <div className="bg-black/30 rounded-xl p-4 border border-green-500/20 space-y-3">
                    <p className="text-xs text-green-400 font-semibold uppercase">🎁 Gift Card Payment</p>
                    {paymentInfo?.giftCardInfo ? (
                      <p className="text-sm text-white leading-relaxed">{paymentInfo.giftCardInfo}</p>
                    ) : (
                      <p className="text-sm text-muted-foreground">Contact admin via Telegram for gift card payment instructions.</p>
                    )}
                    <a href="https://t.me/style0090" target="_blank" rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-sm text-[#29b6f6] hover:underline font-medium">
                      <Send className="w-4 h-4" /> Message on Telegram
                    </a>
                  </div>
                )}
              </div>

              {/* Right: submit form */}
              <form onSubmit={handleSubmitDeposit} className="space-y-4">
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Submit Request</h3>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Amount (USD $)</label>
                  <Input type="number" step="0.01" min="1" placeholder="e.g. 20" value={depositAmount} onChange={e => setDepositAmount(e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    {selectedIntlMethod === "giftcard" ? "Gift Card Code" : "Transaction ID / Hash"}
                  </label>
                  <Input
                    type="text"
                    placeholder={selectedIntlMethod === "giftcard" ? "e.g. XXXX-XXXX-XXXX-XXXX" : selectedIntlMethod === "binance" ? "e.g. Binance Pay order ID" : "e.g. 0x1a2b3c..."}
                    value={depositProof}
                    onChange={e => setDepositProof(e.target.value)}
                    required
                  />
                </div>
                <Button type="submit" className="w-full" disabled={submittingDeposit}>
                  {submittingDeposit
                    ? <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Sending...</>
                    : <><Send className="w-4 h-4 mr-2" /> Send Request</>
                  }
                </Button>
                <p className="text-xs text-muted-foreground text-center">Admin will verify and add your balance shortly</p>
              </form>
            </div>
          </motion.section>
        )}

        {/* Georgian Products Section */}
        {isGeorgian === true && (
          <motion.section initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
            <div className="flex items-center gap-3 mb-6">
              <span className="text-2xl">🇬🇪</span>
              <h2 className="text-2xl font-bold">Georgian Products</h2>
              <Badge className="bg-red-500/10 text-red-400 border-red-500/20">ქართული ფასები</Badge>
            </div>

            <div className="flex flex-wrap gap-3 mb-6">
              {GEL_CATEGORIES.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id === selectedCategory ? null : cat.id)}
                  className={`px-5 py-2.5 rounded-xl text-sm font-semibold transition-all border ${
                    selectedCategory === cat.id
                      ? "bg-primary text-white border-primary shadow-lg shadow-primary/30 scale-105"
                      : "bg-white/5 text-muted-foreground border-white/10 hover:text-white hover:bg-white/10 hover:border-white/20"
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>

            {selectedCat ? (
              <motion.div
                key={selectedCat.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="grid grid-cols-1 md:grid-cols-3 gap-5"
              >
                {GEL_DURATIONS.map(dur => {
                  const price = getGelPrice(selectedCat.tier, dur.id);
                  const productId = `${selectedCat.id}-${dur.id}`;
                  const canAfford = (user?.balance || 0) >= price;
                  const isBuying = purchasing === productId;
                  return (
                    <Card key={dur.id} className="flex flex-col hover:border-primary/50 hover:shadow-xl hover:shadow-primary/10 transition-all duration-300 overflow-hidden bg-card/50 backdrop-blur-sm border-white/10">
                      <CardHeader>
                        <div className="flex justify-between items-start mb-2">
                          <div className="p-2.5 rounded-xl bg-primary/10 text-primary"><KeyRound className="w-6 h-6" /></div>
                          <Badge variant="secondary" className="font-mono text-sm">₾{price}</Badge>
                        </div>
                        <CardTitle className="text-2xl mt-3">{selectedCat.name}</CardTitle>
                        <CardDescription className="text-base">{dur.label} Access</CardDescription>
                      </CardHeader>
                      <CardContent className="flex-1">
                        <div className="text-sm font-medium text-muted-foreground bg-black/20 rounded-lg p-3 inline-flex items-center gap-2 border border-white/5">
                          <Clock className="w-4 h-4" /> Valid for {dur.label.toLowerCase()}
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Button className="w-full" size="lg" onClick={() => handlePurchase(productId)} disabled={isBuying || purchaseMutation.isPending || !canAfford}>
                          {isBuying ? "Processing..." : !canAfford ? "Insufficient Balance" : `Buy for ₾${price}`}
                        </Button>
                      </CardFooter>
                    </Card>
                  );
                })}
              </motion.div>
            ) : (
              <p className="text-muted-foreground text-sm">👆 Choose a product above to see prices</p>
            )}
          </motion.section>
        )}

        {/* USD Products (non-Georgians) */}
        {isGeorgian === false && (
          <section>
            <div className="flex items-center gap-2 mb-6">
              <ShoppingCart className="w-6 h-6 text-primary" />
              <h2 className="text-2xl font-bold">Available Products</h2>
            </div>
            {loadingProducts ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[1,2,3].map(i => <div key={i} className="h-64 rounded-3xl bg-white/5 animate-pulse" />)}
              </div>
            ) : (
              <motion.div variants={containerVariants} initial="hidden" animate="show" className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {products.map(product => (
                  <motion.div key={product.id} variants={itemVariants}>
                    <Card className="h-full flex flex-col hover:border-primary/50 hover:shadow-xl hover:shadow-primary/10 transition-all duration-300 overflow-hidden bg-card/50 backdrop-blur-sm border-white/5">
                      <CardHeader>
                        <div className="flex justify-between items-start mb-2">
                          <div className="p-2.5 rounded-xl bg-primary/10 text-primary"><KeyRound className="w-6 h-6" /></div>
                          <Badge variant="secondary" className="font-mono text-sm">${product.price}</Badge>
                        </div>
                        <CardTitle className="text-2xl mt-4">{product.name}</CardTitle>
                        <CardDescription className="text-base">{product.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="flex-1">
                        <div className="text-sm font-medium text-muted-foreground bg-black/20 rounded-lg p-3 inline-flex items-center gap-2 border border-white/5">
                          <Clock className="w-4 h-4" /> Valid for {product.duration}
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Button className="w-full" size="lg" onClick={() => handlePurchase(product.id)} disabled={purchaseMutation.isPending || (user?.balance || 0) < product.price}>
                          {(user?.balance || 0) < product.price ? "Insufficient Balance" : "Purchase Instantly"}
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            )}
          </section>
        )}

        {isGeorgian === null && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1,2,3].map(i => <div key={i} className="h-64 rounded-3xl bg-white/5 animate-pulse" />)}
          </div>
        )}

        {/* Purchase History */}
        <section>
          <div className="flex items-center gap-2 mb-6">
            <Clock className="w-6 h-6 text-primary" />
            <h2 className="text-2xl font-bold">Purchase History</h2>
          </div>
          <Card className="overflow-hidden bg-card/50 backdrop-blur-sm border-white/5">
            {loadingHistory ? (
              <div className="p-8 text-center text-muted-foreground animate-pulse">Loading history...</div>
            ) : history.length === 0 ? (
              <div className="p-12 text-center flex flex-col items-center">
                <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-4">
                  <ShoppingCart className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-medium mb-1">No purchases yet</h3>
                <p className="text-muted-foreground">Buy a product to see your keys here.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="bg-black/20 text-muted-foreground border-b border-white/5">
                    <tr>
                      <th className="px-6 py-4 font-medium">Product</th>
                      <th className="px-6 py-4 font-medium">Key</th>
                      <th className="px-6 py-4 font-medium">Price</th>
                      <th className="px-6 py-4 font-medium">Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {history.map(item => (
                      <tr key={item.id} className="hover:bg-white/[0.02] transition-colors">
                        <td className="px-6 py-4 font-medium">{item.productName}</td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <code className="px-2 py-1 rounded bg-black/30 text-primary border border-primary/20 select-all text-xs">{item.keyValue}</code>
                            <button onClick={() => copyToClipboard(item.keyValue)} className="p-1 rounded bg-white/5 hover:bg-white/10"><Copy className="w-3 h-3" /></button>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-muted-foreground">{item.price}</td>
                        <td className="px-6 py-4 text-muted-foreground">{format(new Date(item.purchasedAt), "MMM d, yyyy HH:mm")}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </section>

      </div>
    </AppLayout>
  );
}
