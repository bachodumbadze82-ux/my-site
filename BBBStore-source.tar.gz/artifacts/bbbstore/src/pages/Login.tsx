import React, { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { KeyRound, Zap, Shield, Star } from "lucide-react";
import { motion } from "framer-motion";

const features = [
  { icon: <Zap className="w-5 h-5 text-yellow-400" />, text: "Instant key delivery after purchase" },
  { icon: <Shield className="w-5 h-5 text-green-400" />, text: "Secure & encrypted transactions" },
  { icon: <Star className="w-5 h-5 text-primary" />, text: "Premium quality — guaranteed" },
];

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { login, isLoggingIn, user } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (user) setLocation("/dashboard");
  }, [user, setLocation]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) return;
    login({ username, password });
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-background overflow-hidden">

      {/* Left branding panel */}
      <div className="hidden md:flex flex-1 relative items-center justify-center overflow-hidden border-r border-white/5">
        {/* Background orbs */}
        <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-primary/25 glow-orb" />
        <div className="absolute bottom-[-15%] right-[-10%] w-[400px] h-[400px] bg-accent/20 glow-orb" style={{ animationDelay: "2s" }} />
        <div className="absolute top-[40%] right-[20%] w-[200px] h-[200px] bg-purple-500/15 glow-orb" style={{ animationDelay: "1s" }} />

        <div className="relative z-10 p-14 max-w-lg w-full">
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex items-center gap-3 mb-10"
          >
            <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-2xl shadow-primary/40">
              <KeyRound className="h-6 w-6 text-white" />
            </div>
            <span className="font-display font-black text-2xl tracking-tight text-white">BBB STORE</span>
          </motion.div>

          {/* Welcome headline */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15 }}
          >
            <h1 className="text-6xl font-display font-black text-white leading-[1.1] mb-4">
              Welcome to<br />
              <span className="shimmer-text">BBB STORE</span>
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed mb-8">
              Your success starts with the right key. Join thousands of users who trust BBB STORE for fast, secure, and reliable digital access.
            </p>
          </motion.div>

          {/* Motivational quote */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="border-l-4 border-primary pl-4 mb-10"
          >
            <p className="text-white font-semibold text-lg italic">
              "The best investment you can make is in yourself."
            </p>
            <p className="text-muted-foreground text-sm mt-1">— Unlock your potential today</p>
          </motion.div>

          {/* Feature list */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.45 }}
            className="space-y-4"
          >
            {features.map((f, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -15 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + i * 0.1 }}
                className="flex items-center gap-3 bg-white/5 rounded-xl px-4 py-3 border border-white/5"
              >
                <div className="p-1.5 rounded-lg bg-white/5">{f.icon}</div>
                <span className="text-sm font-medium text-foreground">{f.text}</span>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* Right login form */}
      <div className="flex-1 flex items-center justify-center p-8 relative">
        {/* Mobile background orbs */}
        <div className="absolute top-0 right-0 w-[300px] h-[300px] bg-primary/20 glow-orb md:hidden" />
        <div className="absolute bottom-0 left-0 w-[200px] h-[200px] bg-accent/15 glow-orb md:hidden" style={{ animationDelay: "2s" }} />

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4 }}
          className="w-full max-w-md relative z-10"
        >
          {/* Mobile logo */}
          <div className="flex flex-col items-center mb-8 md:hidden">
            <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-2xl shadow-primary/40 mb-3">
              <KeyRound className="h-7 w-7 text-white" />
            </div>
            <h1 className="font-display font-black text-3xl shimmer-text">BBB STORE</h1>
            <p className="text-muted-foreground text-sm mt-1 text-center">Your gateway to premium access</p>
          </div>

          {/* Glass card */}
          <div className="glass-panel rounded-3xl p-8 sm:p-10">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-display font-bold mb-2">Welcome Back 👋</h2>
              <p className="text-muted-foreground">Sign in to access your dashboard</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <label className="text-sm font-medium ml-1">Username</label>
                <Input
                  type="text"
                  placeholder="Enter your username"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium ml-1">Password</label>
                <Input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" className="w-full h-12 text-base font-semibold mt-2 bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity" isLoading={isLoggingIn}>
                Sign In →
              </Button>
            </form>

            <p className="mt-8 text-center text-sm text-muted-foreground">
              Don't have an account?{" "}
              <Link href="/register" className="text-primary font-semibold hover:underline">
                Create one free
              </Link>
            </p>
          </div>

          {/* Telegram help link */}
          <p className="text-center text-xs text-muted-foreground mt-6">
            Need help?{" "}
            <a
              href="https://t.me/style0090"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline font-medium"
            >
              Contact us on Telegram
            </a>
          </p>
        </motion.div>
      </div>
    </div>
  );
}
